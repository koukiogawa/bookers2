# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'ccd18f502f3b49e9da9576eaeba8c1fa3272043d420ffea57a63402732f213cd660aad9d0716cd665470ed3495c6a2295105f01b8a3d14b26fd7df7791e9c3a9'