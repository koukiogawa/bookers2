class UsersController < ApplicationController
  def show
  end

  def edit
  end
  
  def index
    @user = User.all
  end
  
  
end
