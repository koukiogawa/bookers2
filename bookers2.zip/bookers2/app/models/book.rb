class Book < ApplicationRecord
  
  belongs_to :user
end
