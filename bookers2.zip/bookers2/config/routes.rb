Rails.application.routes.draw do

  resources :books, only: [:index, :new, :create, :show, :edit, :destroy]
  resources :users, only: [:edit, :show, :in]
  devise_for :users
  root to: 'homes#top'
end
